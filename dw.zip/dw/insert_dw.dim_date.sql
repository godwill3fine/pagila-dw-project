INSERT INTO dw.dim_date (date_key, year, quarter, month, day, day_of_week, is_weekend)
SELECT DISTINCT
    DATE(rental_date) AS date_key,
    EXTRACT(YEAR FROM rental_date) AS year,
    EXTRACT(QUARTER FROM rental_date) AS quarter,
    EXTRACT(MONTH FROM rental_date) AS month,
    EXTRACT(DAY FROM rental_date) AS day,
    EXTRACT(ISODOW FROM rental_date) AS day_of_week,
    CASE WHEN EXTRACT(ISODOW FROM rental_date) IN (6, 7) THEN TRUE ELSE FALSE END AS is_weekend
FROM public.rental
WHERE rental_date IS NOT NULL;