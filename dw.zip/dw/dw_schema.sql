-- Create a separate schema for the Data Warehouse
CREATE SCHEMA IF NOT EXISTS dw;

-- ==========================================
-- 1. DIMENSION TABLES (The "Context")
-- ==========================================

-- Denormalizing customer, address, city, and country into one table
CREATE TABLE dw.dim_customer (
    customer_id INT PRIMARY KEY,
    first_name VARCHAR(45),
    last_name VARCHAR(45),
    email VARCHAR(50),
    active INT,
    address VARCHAR(50),
    city VARCHAR(50),
    country VARCHAR(50)
);

-- Denormalizing film and category
CREATE TABLE dw.dim_film (
    film_id INT PRIMARY KEY,
    title VARCHAR(255),
    release_year INT,
    rental_rate NUMERIC(4,2),
    rating VARCHAR(10),
    category_name VARCHAR(25)
);

-- Denormalizing store, staff (manager), address, city, and country
CREATE TABLE dw.dim_store (
    store_id INT PRIMARY KEY,
    manager_name VARCHAR(90),
    address VARCHAR(50),
    city VARCHAR(50),
    country VARCHAR(50)
);

-- A standard time dimension to make time-series analysis fast and easy
CREATE TABLE dw.dim_date (
    date_key DATE PRIMARY KEY,
    year INT,
    quarter INT,
    month INT,
    day INT,
    day_of_week INT,
    is_weekend BOOLEAN
);

-- ==========================================
-- 2. FACT TABLE (The "Metrics")
-- ==========================================

CREATE TABLE dw.fact_rentals (
    rental_id INT PRIMARY KEY,
    customer_id INT REFERENCES dw.dim_customer(customer_id),
    film_id INT REFERENCES dw.dim_film(film_id),
    store_id INT REFERENCES dw.dim_store(store_id),
    rental_date DATE REFERENCES dw.dim_date(date_key),
    return_date DATE,
    amount NUMERIC(5,2)
);