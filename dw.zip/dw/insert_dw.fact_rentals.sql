INSERT INTO dw.fact_rentals (rental_id, customer_id, film_id, store_id, rental_date, return_date, amount)
SELECT 
    r.rental_id,
    r.customer_id,
    i.film_id,
    i.store_id,
    DATE(r.rental_date) AS rental_date,
    DATE(r.return_date) AS return_date,
    p.total_amount AS amount
FROM public.rental r
-- 1. Bridge through inventory to get the film and store details
INNER JOIN public.inventory i ON r.inventory_id = i.inventory_id
-- 2. Safely join the pre-calculated payments
LEFT JOIN (
    SELECT rental_id, SUM(amount) AS total_amount
    FROM public.payment
    GROUP BY rental_id
) p ON r.rental_id = p.rental_id;