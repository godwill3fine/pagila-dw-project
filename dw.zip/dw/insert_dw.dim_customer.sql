INSERT INTO dw.dim_customer (customer_id, first_name, last_name, email, active, address, city, country)
SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    c.active,
    a.address,
    ci.city,
    co.country
FROM public.customer c
INNER JOIN public.address a ON c.address_id = a.address_id
INNER JOIN public.city ci ON a.city_id = ci.city_id
INNER JOIN public.country co ON ci.country_id = co.country_id;