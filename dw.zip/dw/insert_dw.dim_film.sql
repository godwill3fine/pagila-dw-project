INSERT INTO dw.dim_film (film_id, title, release_year, rental_rate, rating, category_name)
SELECT 
    f.film_id,
    f.title,
    f.release_year,
    f.rental_rate,
    f.rating::VARCHAR, 
    COALESCE(c.name, 'Uncategorized') AS category_name
FROM public.film f
LEFT JOIN public.film_category fc ON f.film_id = fc.film_id
LEFT JOIN public.category c ON fc.category_id = c.category_id;