--Top 10 customers by spending
SELECT 
    c.customer_id,
    c.first_name || ' ' || c.last_name AS customer_name,
    c.city,
    c.country,
    SUM(f.amount) AS total_spent
FROM dw.fact_rentals f
INNER JOIN dw.dim_customer c ON f.customer_id = c.customer_id
GROUP BY 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.city,
    c.country
ORDER BY 
    total_spent DESC
LIMIT 10;