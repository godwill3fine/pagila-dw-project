--Total revenue per store
SELECT 
    s.store_id,
    s.manager_name,
    s.city,
    SUM(f.amount) AS total_revenue
FROM dw.fact_rentals f
INNER JOIN dw.dim_store s ON f.store_id = s.store_id
GROUP BY 
    s.store_id,
    s.manager_name,
    s.city
ORDER BY 
    total_revenue DESC;