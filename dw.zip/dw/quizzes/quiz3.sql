--Monthly rental trends
SELECT 
    d.year,
    d.month,
    COUNT(f.rental_id) AS total_rentals,
    SUM(f.amount) AS total_revenue
FROM dw.fact_rentals f
INNER JOIN dw.dim_date d ON f.rental_date = d.date_key
GROUP BY 
    d.year,
    d.month
ORDER BY 
    d.year,
    d.month;