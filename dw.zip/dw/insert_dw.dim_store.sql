INSERT INTO dw.dim_store (store_id, manager_name, address, city, country)
SELECT 
    s.store_id,
    st.first_name || ' ' || st.last_name AS manager_name,
    a.address,
    ci.city,
    co.country
FROM public.store s
INNER JOIN public.staff st ON s.manager_staff_id = st.staff_id
INNER JOIN public.address a ON s.address_id = a.address_id
INNER JOIN public.city ci ON a.city_id = ci.city_id
INNER JOIN public.country co ON ci.country_id = co.country_id;